#include <iostream>
#include <string>
#include <sstream> // this will allow you to use stringstream in your program

using namespace std;

int main() {
    // Cria um objeto do tipo string stream, para input/output strings
   stringstream ss; 
   
   // Define variável str
   string str = "200";
   
   // Define a variável num do tipo int
   int num;
   
   
   // Extrai a string da variável str
   ss << str;
   
   // Atribui a num o valor convertido para inteiro
   ss >> num;
   
   //Imprime o resultado final
   cout << num << endl;
}