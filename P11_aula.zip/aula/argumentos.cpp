#include <iostream>

using namespace std;

// passagem por valor – troca não funciona
int somarNumeros(int x, int y) {
    int soma = x + y;
    return soma;
}

// C – uso de apontadores
/*void trocaAp(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}*/

// C++ – uso de referências
void trocaRef(int &x, int &y) {
    int temp = x;
    x = y;
    y = temp;
}

// Teste das funções
int main() {
    int a = 1, b = 2;
    int soma = somarNumeros(a, b);
    cout << "Soma = " << soma << endl;

    trocaRef(a, b); // troca valores de a e b
    cout << "a =" << a << '\n';
    cout << "b =" << b << '\n';

    // se não colocar return, o C++ adiciona implicitamente o return 0
}