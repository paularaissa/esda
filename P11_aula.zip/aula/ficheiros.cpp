#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ifstream origem("pais_leitura.txt"); // define variável 'origem' e abre ficheiro para leitura
    // para leitura
    if (!origem) { //testa se conseguiu abrir o ficheiro
        cout << "Erro a abrir ficheiro f1\n"; 
        return -1; 
    }
    ofstream destino ("pais_escrita.txt"); // define variável 'destino' e abre ficheiro para escrita
    if (!destino) { // teste se conseguiu abrir o ficheiro
        cerr << "Erro a abrir ficheiro f2\n"; 
        return -1; 
    }
    char c;
    // EOF - testa se chegou ao fim do ficheiro
    while ( (c = origem.get()) != EOF ) // lê informação do ficheiro
        destino.put(c); // escreve informação no ficheiro
    if (!origem.eof() || !destino){ // em bool dá false após erro
        cerr << "Erro\n"; 
        return -1; 
    }
    return 0;
} // ficheiros são fechados automaticamente