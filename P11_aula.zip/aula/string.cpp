#include <string> // definições no espaço de nomes std
#include <iostream> // idem
using namespace std; // traz nomes de std para global

int main() { 
    string primeiro, ultimo, completo;
    cin >> primeiro; // lê do teclado (pára em espaço, tab ou newline)
    cin >> ultimo; // idem
    if (primeiro == ultimo) // compara strings
        cout << "Primeiro e último nome iguais!\n";
    completo = primeiro + " " + ultimo; // concatena e copia
    cout << completo << endl; // escreve
    return 0;
}