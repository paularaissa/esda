// o meu primeiro programa em C++

#include<iostream>

int main() {
    std::cout << "Bom dia" << std::endl;
}



