#include <iostream>
#include <string>

using namespace std;

int main() {
   // Definir a string
   string str = "20";
   // Imprime string
   cout << "String: " << str << endl;

   // Converter string para inteiro
   int num = stoi(str);

   // Converter string para float
   float num2 = stof("17.5");
   
   // Imprime inteiro
   cout << "Inteiro " << num << endl;
   
   // Imprime float
   cout << "Float " << num2 << endl;
}
